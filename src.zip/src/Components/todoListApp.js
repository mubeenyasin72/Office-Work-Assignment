import React, { Component } from 'react';
// import './todoListApp.css';
class todoListApp extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            counter:0
         };
    }
    formateCount = ()=>
    {
        const {counter} = this.state;
        return counter === 0 ? "Zero": counter;
        
    }
    getBadgeClasses =()=>{
        let classes  = "badge m-2 badge-";
        classes +=this.state.counter === 0 ? "warning" : "primary";
        return classes; 
    }
    handleIncrement =()=>{
        this.setState({
            counter:this.state.counter+1
        });
        console.log(this.state.counter);
    }
    managecounter =()=>{
        return(
            <span className ={this.getBadgeClasses()} >
            {
            this.formateCount()
            }
        </span>
        );
    }
    handelArray = ()=>
    {
        if(this.props.taskList.length === 0)
        {
            return<p className="badge m-2 badge-warning">The Given Todo List is Empty </p>
        }
        else
        {
            return(
                <div className="todo_Container">
                    {
                        this.props.taskList.map(ts=>
                            <div style ={styles.container} key={ts.id}>
                                {ts.task}
                                {this.managecounter()}
                                <button onClick={()=>this.props.delete(ts.id)} className="btn btn-danger btn-sm">
                                    Delete
                                </button>
                                <button className="btn btn-primary btn-sm" onClick={()=>this.props.editData(ts.id)}>
                                Edit
                                </button>
                                <button className="btn btn-secondary btn-sm" onClick={()=>{this.handleIncrement()}}>
                                    Increment
                                </button>
                                <input type="input" placeholder="Enter a value" onChange={this.props.onChange}/>
                            </div>
                        )
                    }
                </div>
            )
        }
    }
    render() {
        return (
            <React.Fragment>
                <div style={{textAlign:"center"}}>
                    {
                        this.handelArray()
                    }
                </div>
            </React.Fragment>    
        );
    }
}

export default todoListApp;
const styles = {
    container: {
        padding:"10px",
        width: "100%", 
        height: 50, 
        backgroundColor: "gray", 
        marginTop: 5, 
        color: "white"
    }
}