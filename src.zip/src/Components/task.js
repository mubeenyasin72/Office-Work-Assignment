class Task{
    constructor(Task, NewId){
        this.task =Task; 
        this.id=NewId;
    }
}
export default Task;