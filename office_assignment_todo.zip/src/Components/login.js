import React, { Component } from 'react';
class login extends Component {
    // constructor(props) {
    //     super(props);
    //     this.state = {  };
    // }
    render() {
        return (
            <React.Fragment>
                <div>
                    <h2>
                        this is login Page
                    </h2>
                </div>
            </React.Fragment>    
        );
    }
}

export default login;