import React, { Component } from 'react';
class combineCounter extends Component {
    // constructor(props) {
    //     super(props);
    //     this.state = {  };
    // }
    render() {
        return (
            <React.Fragment>
                <div>
                    <h2>
                        this is combine Counter page
                    </h2>
                </div>
            </React.Fragment>

        );
    }
}

export default combineCounter;